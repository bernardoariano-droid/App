package com.angolearn.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
