export interface Lesson {
  id: string;
  title: string;
  videoUrl: string;
  duration: string;
}

export interface Module {
  id: string;
  title: string;
  lessons: Lesson[];
}

export interface Course {
  id: string;
  title: string;
  instructor: string;
  price: number;
  category: string;
  thumbnail: string;
  description: string;
  duration: string;
  lessons: number;
  sales?: number;
  rating?: number;
  modules?: Module[];
  purchased?: boolean;
  progress?: number;
}

export const COURSES: Course[] = [
  {
    id: "1",
    title: "Marketing Digital para Empreendedores Angolanos",
    instructor: "Mauro de Oliveira",
    price: 15000,
    category: "Negócios",
    thumbnail: "https://picsum.photos/seed/marketing/800/600",
    description: "Aprenda a vender mais usando as redes sociais mais populares em Angola: Facebook e WhatsApp Business.",
    duration: "12h",
    lessons: 24,
    sales: 145,
    rating: 4.8,
    purchased: true,
    progress: 45,
  },
  {
    id: "2",
    title: "Desenvolvimento Web com React e Node.js",
    instructor: "Sílvia Santos",
    price: 45000,
    category: "Tecnologia",
    thumbnail: "https://picsum.photos/seed/code/800/600",
    description: "Do zero ao profissional. Aprenda as tecnologias mais requisitadas no mercado de TI em Luanda.",
    duration: "40h",
    lessons: 60,
    sales: 89,
    rating: 4.9,
    purchased: true,
    progress: 12,
  },
  {
    id: "3",
    title: "Gestão de Finanças Pessoais em Kwanza",
    instructor: "António Gouveia",
    price: 5000,
    category: "Finanças",
    thumbnail: "https://picsum.photos/seed/finance/800/600",
    description: "Como poupar e investir o seu dinheiro num cenário de inflação e variações cambiais.",
    duration: "5h",
    lessons: 10,
    sales: 320,
    rating: 4.7,
  },
  {
    id: "4",
    title: "Culinária Angolana Moderna",
    instructor: "Chef Maria",
    price: 12500,
    category: "Estilo de Vida",
    thumbnail: "https://picsum.photos/seed/food/800/600",
    description: "Aprenda a dar um toque gourmet aos pratos tradicionais como o Funge e o Muamba.",
    duration: "8h",
    lessons: 15,
    sales: 56,
    rating: 4.5,
  },
  {
    id: "5",
    title: "Inglês para Negócios Internacionais",
    instructor: "John Doe",
    price: 25000,
    category: "Línguas",
    thumbnail: "https://picsum.photos/seed/english/800/600",
    description: "Prepare-se para trabalhar em multinacionais do setor petrolífero e diamantífero.",
    duration: "20h",
    lessons: 30,
    sales: 112,
    rating: 4.6,
  }
];

export const COMMISSION_SPLIT = {
  SYSTEM: 0.10, // 10%
  AFFILIATE: 0.20, // 20%
  CREATOR: 0.70, // 70%
};

export const calculateSplit = (amount: number) => {
  return {
    system: amount * COMMISSION_SPLIT.SYSTEM,
    affiliate: amount * COMMISSION_SPLIT.AFFILIATE,
    creator: amount * COMMISSION_SPLIT.CREATOR,
  };
};

export const MOCK_STATS = {
  instructor: {
    totalEarnings: 2450000,
    totalStudents: 1240,
    activeCourses: 3,
    recentSales: [
      { id: "s1", course: "Marketing Digital", student: "João Silva", date: "2026-03-28", amount: 15000 },
      { id: "s2", course: "Marketing Digital", student: "Maria Antónia", date: "2026-03-27", amount: 15000 },
      { id: "s3", course: "Gestão de Finanças", student: "Carlos Bento", date: "2026-03-27", amount: 5000 },
    ]
  },
  affiliate: {
    totalCommission: 450000,
    totalClicks: 5600,
    conversions: 45,
    rank: "Ouro",
    recentReferrals: [
      { id: "r1", course: "Desenvolvimento Web", date: "2026-03-28", commission: 4500 },
      { id: "r2", course: "Marketing Digital", date: "2026-03-26", commission: 1500 },
    ]
  }
};
