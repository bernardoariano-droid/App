import { BrowserRouter as Router, Routes, Route, Link, useLocation } from "react-router-dom";
import React, { useState, useRef, ChangeEvent, useEffect } from "react";
import { 
  BookOpen, ShoppingCart, User, Search, Menu, X, 
  GraduationCap, CreditCard, CheckCircle2, 
  PlusCircle, Users, DollarSign, TrendingUp, Link as LinkIcon, 
  Award, BarChart3, Settings, LogOut, ChevronRight, Copy,
  Trash2, GripVertical, Video, FileVideo, ArrowLeft, Upload,
  Smartphone, Building2, Rocket, ShieldCheck, Zap
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Toaster, toast } from "sonner";
import { useNavigate, useParams } from "react-router-dom";
import { COURSES, Course, MOCK_STATS, Module, Lesson, calculateSplit, COMMISSION_SPLIT } from "./data/courses";

// --- Types ---
type UserRole = "student" | "instructor" | "affiliate";

// --- Utility ---
const cn = (...classes: (string | boolean | undefined)[]) => classes.filter(Boolean).join(" ");

// --- Components ---

const Navbar = ({ role, setRole, isAuthenticated, setIsAuthenticated }: { 
  role: UserRole, 
  setRole: (r: UserRole) => void,
  isAuthenticated: boolean,
  setIsAuthenticated: (a: boolean) => void
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) {
      toast.info("Para instalar, use a opção 'Adicionar ao ecrã principal' no seu navegador.");
      return;
    }
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };

  const handleDashboardRedirect = () => {
    if (role === "student") navigate("/meus-cursos");
    else if (role === "instructor") navigate("/instrutor");
    else if (role === "affiliate") navigate("/afiliado");
  };

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <Link to="/" className="flex items-center gap-2">
            <div className="bg-orange-600 p-1.5 rounded-lg">
              <GraduationCap className="text-white w-6 h-6" />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900">AngoLearn</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-orange-600 transition-colors" />
              <input 
                type="text" 
                placeholder="Pesquisar cursos..." 
                className="pl-10 pr-4 py-2 bg-slate-100 border-none rounded-full text-sm w-64 focus:ring-2 focus:ring-orange-500/20 outline-none transition-all"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    toast.info(`Pesquisando por: ${e.currentTarget.value}`);
                  }
                }}
              />
            </div>

            <Link to="/" className={cn("text-sm font-medium transition-colors", location.pathname === "/" ? "text-orange-600" : "text-slate-600 hover:text-orange-600")}>Catálogo</Link>
            
            {isAuthenticated && (
              <>
                {role === "student" && (
                  <Link to="/meus-cursos" className={cn("text-sm font-medium transition-colors", location.pathname === "/meus-cursos" ? "text-orange-600" : "text-slate-600 hover:text-orange-600")}>Meus Cursos</Link>
                )}
                
                {role === "instructor" && (
                  <Link to="/instrutor" className={cn("text-sm font-medium transition-colors", location.pathname === "/instrutor" ? "text-orange-600" : "text-slate-600 hover:text-orange-600")}>Painel Instrutor</Link>
                )}

                {role === "affiliate" && (
                  <Link to="/afiliado" className={cn("text-sm font-medium transition-colors", location.pathname === "/afiliado" ? "text-orange-600" : "text-slate-600 hover:text-orange-600")}>Painel Afiliado</Link>
                )}
              </>
            )}

            <div className="h-6 w-px bg-slate-200 mx-2" />

            {/* Role Switcher (Demo Only) */}
            <select 
              value={role} 
              onChange={(e) => setRole(e.target.value as UserRole)}
              className="text-xs font-bold bg-slate-100 border-none rounded-full px-3 py-1 text-slate-600 focus:ring-0 cursor-pointer outline-none"
            >
              <option value="student">Modo Aluno</option>
              <option value="instructor">Modo Instrutor</option>
              <option value="affiliate">Modo Afiliado</option>
            </select>

            <div className="flex items-center gap-4">
              <button 
                onClick={handleInstallClick}
                className="hidden lg:flex items-center gap-2 text-slate-400 hover:text-orange-600 transition-colors mr-2"
                title="Instalar Aplicativo"
              >
                <Smartphone className="w-5 h-5" />
                <span className="text-xs font-bold">Instalar App</span>
              </button>

              {isAuthenticated ? (
                <div className="flex items-center gap-3">
                  <Link to="/perfil" className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-full border border-slate-200 hover:bg-slate-100 transition-colors">
                    <User className="w-4 h-4 text-slate-600" />
                    <span className="text-xs font-semibold text-slate-700">Minha Conta</span>
                  </Link>
                  <button 
                    onClick={() => {
                      setIsAuthenticated(false);
                      toast.error("Sessão terminada com sucesso.");
                      navigate("/login");
                    }}
                    className="p-2 text-slate-400 hover:text-red-600 transition-colors"
                    title="Sair"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <Link to="/login" className="text-sm font-bold text-slate-600 hover:text-orange-600 transition-colors">Entrar</Link>
                  <Link to="/cadastro" className="px-5 py-2 bg-orange-600 text-white text-sm font-bold rounded-full hover:bg-orange-700 transition-all shadow-lg shadow-orange-100">Criar Conta</Link>
                </div>
              )}
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-4">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 text-slate-600">
              {isMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-slate-100 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-2">
              <Link to="/" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 text-base font-medium text-slate-700 hover:bg-slate-50 rounded-md">Catálogo</Link>
              <Link to="/meus-cursos" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 text-base font-medium text-slate-700 hover:bg-slate-50 rounded-md">Meus Cursos</Link>
              <Link to="/instrutor" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 text-base font-medium text-slate-700 hover:bg-slate-50 rounded-md">Painel Instrutor</Link>
              <Link to="/afiliado" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 text-base font-medium text-slate-700 hover:bg-slate-50 rounded-md">Painel Afiliado</Link>
              
              <button 
                onClick={handleInstallClick}
                className="w-full text-left px-3 py-2 text-base font-medium text-slate-700 hover:bg-slate-50 rounded-md flex items-center gap-2"
              >
                <Smartphone className="w-5 h-5 text-slate-400" />
                Instalar Aplicativo
              </button>

              {isAuthenticated && (
                <button 
                  onClick={() => {
                    setIsAuthenticated(false);
                    toast.error("Sessão terminada com sucesso.");
                    setIsMenuOpen(false);
                    navigate("/login");
                  }}
                  className="w-full text-left px-3 py-2 text-base font-medium text-red-600 hover:bg-red-50 rounded-md flex items-center gap-2"
                >
                  <LogOut className="w-5 h-5" />
                  Terminar Sessão
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const CourseCard = ({ course }: { course: Course }) => (
  <Link to={`/curso/${course.id}`} className="group bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-300 flex flex-col">
    <div className="relative aspect-video overflow-hidden">
      <img 
        src={course.thumbnail} 
        alt={course.title} 
        className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500"
        referrerPolicy="no-referrer"
      />
      <div className="absolute top-3 left-3">
        <span className="px-2.5 py-1 bg-white/90 backdrop-blur-sm text-[10px] font-bold uppercase tracking-wider rounded-full text-slate-700 border border-white/20 shadow-sm">
          {course.category}
        </span>
      </div>
    </div>
    <div className="p-5 flex-1 flex flex-col">
      <h3 className="text-lg font-bold text-slate-900 leading-tight mb-2 group-hover:text-orange-600 transition-colors">
        {course.title}
      </h3>
      <p className="text-sm text-slate-500 mb-4 line-clamp-2">{course.description}</p>
      <div className="mt-auto pt-4 border-t border-slate-50 flex items-center justify-between">
        <div className="flex flex-col">
          <span className="text-xs text-slate-400">Investimento</span>
          <span className="text-lg font-black text-slate-900">
            {course.price.toLocaleString('pt-AO')} <span className="text-xs font-bold">Kz</span>
          </span>
        </div>
        <div className="flex items-center gap-1 text-slate-400 text-xs font-medium">
          <BookOpen className="w-3.5 h-3.5" />
          <span>{course.lessons} aulas</span>
        </div>
      </div>
    </div>
  </Link>
);

// --- Pages ---

const HomePage = () => {
  const [selectedCategory, setSelectedCategory] = useState("Todos");
  const [searchQuery, setSearchQuery] = useState("");
  const [isHowItWorksOpen, setIsHowItWorksOpen] = useState(false);
  const categories = ["Todos", ...Array.from(new Set(COURSES.map(c => c.category)))];

  const filteredCourses = COURSES.filter(course => {
    const matchesCategory = selectedCategory === "Todos" || course.category === selectedCategory;
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         course.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const courseGridRef = useRef<HTMLDivElement>(null);

  const scrollToCourses = () => {
    courseGridRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleHowItWorks = () => {
    setIsHowItWorksOpen(true);
  };

  return (
    <div className="space-y-16 pb-20">
      <HowItWorksModal isOpen={isHowItWorksOpen} onClose={() => setIsHowItWorksOpen(false)} />
      {/* Hero */}
      <section className="relative py-16 px-4 overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-orange-100 rounded-full blur-3xl opacity-50 animate-pulse" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-100 rounded-full blur-3xl opacity-50 animate-pulse" />
        </div>
        
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-black text-slate-900 tracking-tight"
          >
            Aprenda habilidades que o <span className="text-orange-600">mercado angolano</span> procura.
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-lg text-slate-600 max-w-2xl mx-auto"
          >
            Cursos práticos criados por especialistas locais para impulsionar a sua carreira ou o seu negócio em Angola.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="max-w-xl mx-auto mt-8 relative group"
          >
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-orange-600 transition-colors" />
            <input 
              type="text" 
              placeholder="O que você quer aprender hoje?"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-4 bg-white border-2 border-slate-100 rounded-2xl shadow-xl shadow-slate-200/50 outline-none focus:border-orange-600 transition-all text-slate-900 font-medium"
            />
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex flex-wrap justify-center gap-4 pt-4"
          >
            <button 
              onClick={scrollToCourses}
              className="px-8 py-4 bg-orange-600 text-white font-bold rounded-2xl hover:bg-orange-700 transition-all shadow-lg shadow-orange-200 active:scale-95"
            >
              Ver Catálogo
            </button>
            <button 
              onClick={handleHowItWorks}
              className="px-8 py-4 bg-white text-slate-900 font-bold rounded-2xl border border-slate-200 hover:bg-slate-50 transition-all active:scale-95"
            >
              Como Funciona
            </button>
          </motion.div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-2xl font-bold text-slate-900">Navegar por Categoria</h2>
          <p className="text-slate-500">Escolha a área que deseja dominar.</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                setSelectedCategory(cat);
                scrollToCourses();
              }}
              className={cn(
                "flex flex-col items-center justify-center p-6 rounded-3xl border transition-all duration-300 gap-3 group",
                selectedCategory === cat
                  ? "bg-orange-600 border-orange-600 text-white shadow-xl shadow-orange-100"
                  : "bg-white border-slate-100 text-slate-600 hover:border-orange-200 hover:bg-orange-50/30"
              )}
            >
              <div className={cn(
                "w-12 h-12 rounded-2xl flex items-center justify-center transition-colors",
                selectedCategory === cat ? "bg-white/20" : "bg-slate-50 group-hover:bg-orange-100"
              )}>
                {cat === "Todos" && <Menu className="w-6 h-6" />}
                {cat === "Negócios" && <BarChart3 className="w-6 h-6" />}
                {cat === "Tecnologia" && <TrendingUp className="w-6 h-6" />}
                {cat === "Finanças" && <DollarSign className="w-6 h-6" />}
                {cat === "Estilo de Vida" && <Award className="w-6 h-6" />}
                {cat === "Línguas" && <Users className="w-6 h-6" />}
                {!["Todos", "Negócios", "Tecnologia", "Finanças", "Estilo de Vida", "Línguas"].includes(cat) && <BookOpen className="w-6 h-6" />}
              </div>
              <span className="text-sm font-bold">{cat}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Course Grid */}
      <section ref={courseGridRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-24">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Cursos em Destaque</h2>
            <p className="text-slate-500">Explore as áreas com maior crescimento em Angola.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map(cat => (
              <button 
                key={cat} 
                onClick={() => setSelectedCategory(cat)}
                className={cn(
                  "px-4 py-2 text-xs font-bold transition-all rounded-full border",
                  selectedCategory === cat 
                    ? "bg-slate-900 border-slate-900 text-white" 
                    : "bg-white border-slate-200 text-slate-600 hover:border-orange-600 hover:text-orange-600"
                )}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence mode="popLayout">
            {filteredCourses.length > 0 ? (
              filteredCourses.map(course => (
                <motion.div 
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  key={course.id}
                >
                  <CourseCard course={course} />
                </motion.div>
              ))
            ) : (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="col-span-full py-20 text-center space-y-4"
              >
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto">
                  <Search className="w-10 h-10 text-slate-300" />
                </div>
                <h3 className="text-xl font-bold text-slate-900">Nenhum curso encontrado</h3>
                <p className="text-slate-500 max-w-xs mx-auto">Tente ajustar a sua pesquisa ou escolher outra categoria.</p>
                <button 
                  onClick={() => {
                    setSelectedCategory("Todos");
                    setSearchQuery("");
                  }}
                  className="text-orange-600 font-bold hover:underline"
                >
                  Limpar filtros
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>
    </div>
  );
};


const CourseDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const course = COURSES.find(c => c.id === id) || COURSES[0];
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [step, setStep] = useState(1); 

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-8">
          <div className="space-y-4">
            <Link to="/" className="text-sm font-bold text-orange-600 flex items-center gap-1">
              &larr; Voltar ao catálogo
            </Link>
            <h1 className="text-3xl md:text-4xl font-black text-slate-900">{course.title}</h1>
            <div className="flex items-center gap-4 text-sm text-slate-500">
              <span className="flex items-center gap-1 font-medium text-slate-700">
                <User className="w-4 h-4" /> {course.instructor}
              </span>
              <span>•</span>
              <span>{course.duration} de conteúdo</span>
              <span>•</span>
              <span>{course.lessons} aulas</span>
            </div>
          </div>

          <div className="aspect-video rounded-3xl overflow-hidden bg-slate-100 border border-slate-200">
            <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>

          <div className="prose prose-slate max-w-none">
            <h2 className="text-xl font-bold text-slate-900">Sobre este curso</h2>
            <p className="text-slate-600 leading-relaxed">{course.description}</p>
            <p className="text-slate-600 leading-relaxed">
              Este curso foi desenhado especificamente para o contexto de Angola, abordando as ferramentas e estratégias que realmente funcionam no nosso mercado. 
              Ao final, você terá um certificado de conclusão reconhecido pela nossa plataforma.
            </p>
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="sticky top-24 bg-white rounded-3xl border border-slate-200 p-8 shadow-sm space-y-6">
            <div className="space-y-1">
              <span className="text-sm font-bold text-slate-400 uppercase tracking-widest">Preço do Curso</span>
              <div className="text-4xl font-black text-slate-900">
                {course.price.toLocaleString('pt-AO')} <span className="text-xl">Kz</span>
              </div>
            </div>

            <div className="space-y-4">
              <button 
                onClick={() => setIsPurchasing(true)}
                className="w-full py-4 bg-orange-600 text-white font-bold rounded-2xl hover:bg-orange-700 transition-all shadow-lg shadow-orange-200 active:scale-95 flex items-center justify-center gap-2"
              >
                <ShoppingCart className="w-5 h-5" />
                Inscrever-me Agora
              </button>
              <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100">
                <div className="flex items-center gap-2 mb-1">
                  <TrendingUp className="w-4 h-4 text-blue-600" />
                  <span className="text-xs font-bold text-blue-900">Programa de Afiliados</span>
                </div>
                <p className="text-[10px] text-blue-700 leading-tight">
                  Promova este curso e ganhe <span className="font-bold">{(course.price * COMMISSION_SPLIT.AFFILIATE).toLocaleString('pt-AO')} Kz</span> (20%) por cada venda realizada.
                </p>
              </div>
              <p className="text-center text-xs text-slate-400">Acesso vitalício e atualizações gratuitas.</p>
            </div>

            <div className="pt-6 border-t border-slate-100 space-y-4">
              <h4 className="text-sm font-bold text-slate-900">O que está incluído:</h4>
              <ul className="space-y-3">
                {[
                  "Acesso em dispositivos móveis",
                  "Certificado de conclusão",
                  "Material de apoio em PDF",
                  "Suporte via WhatsApp"
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-sm text-slate-600">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isPurchasing && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsPurchasing(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-lg bg-white rounded-[32px] overflow-hidden shadow-2xl"
            >
              <div className="p-8">
                {step === 1 ? (
                  <div className="space-y-6 text-center">
                    <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto">
                      <CreditCard className="text-orange-600 w-8 h-8" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-slate-900">Método de Pagamento</h3>
                      <p className="text-slate-500">Escolha como prefere pagar em Angola.</p>
                    </div>
                    <div className="grid grid-cols-1 gap-3">
                      <button onClick={() => setStep(2)} className="p-4 border-2 border-slate-100 rounded-2xl hover:border-orange-600 hover:bg-orange-50 transition-all text-left flex items-center justify-between group">
                        <div>
                          <p className="font-bold text-slate-900">Multicaixa Express</p>
                          <p className="text-xs text-slate-500">Pagamento instantâneo via telemóvel</p>
                        </div>
                        <div className="w-6 h-6 rounded-full border-2 border-slate-200 group-hover:border-orange-600" />
                      </button>
                      <button onClick={() => setStep(2)} className="p-4 border-2 border-slate-100 rounded-2xl hover:border-orange-600 hover:bg-orange-50 transition-all text-left flex items-center justify-between group">
                        <div>
                          <p className="font-bold text-slate-900">Transferência Bancária (IBAN)</p>
                          <p className="text-xs text-slate-500">Envio de comprovativo manual</p>
                        </div>
                        <div className="w-6 h-6 rounded-full border-2 border-slate-200 group-hover:border-orange-600" />
                      </button>
                    </div>
                  </div>
                ) : step === 2 ? (
                  <div className="space-y-6">
                    <div className="text-center">
                      <h3 className="text-2xl font-bold text-slate-900">Confirmar Pagamento</h3>
                      <p className="text-slate-500">Efetue a transferência para o IBAN abaixo.</p>
                    </div>
                    <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 space-y-4">
                      <div>
                        <p className="text-[10px] font-bold text-slate-400 uppercase">Banco</p>
                        <p className="font-bold text-slate-900">BAI (Banco Angolano de Investimentos)</p>
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-slate-400 uppercase">IBAN</p>
                        <p className="font-mono text-sm font-bold text-slate-900 break-all">AO06 0040 0000 1234 5678 9012 3</p>
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-slate-400 uppercase">Titular</p>
                        <p className="font-bold text-slate-900">AngoLearn Digital Lda.</p>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <label className="block">
                        <span className="text-sm font-bold text-slate-700">Anexar Comprovativo</span>
                        <input type="file" className="mt-1 block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-orange-50 file:text-orange-700 hover:file:bg-orange-100" />
                      </label>
                      <button 
                        onClick={() => {
                          setStep(3);
                          toast.success("Comprovativo enviado com sucesso!");
                        }} 
                        className="w-full py-4 bg-orange-600 text-white font-bold rounded-2xl"
                      >
                        Confirmar Envio
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6 text-center py-4">
                    <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                      <CheckCircle2 className="text-green-600 w-10 h-10" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-slate-900">Pedido Recebido!</h3>
                      <p className="text-slate-500 px-4">O seu pagamento está a ser processado. Receberá acesso ao curso em até 24h úteis.</p>
                    </div>
                    <button 
                      onClick={() => setIsPurchasing(false)}
                      className="w-full py-4 bg-slate-900 text-white font-bold rounded-2xl"
                    >
                      Voltar ao Início
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const MyCoursesPage = () => {
  const purchasedCourses = COURSES.filter(c => c.purchased);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-900">Meus Cursos</h1>
          <p className="text-slate-500">Continue de onde parou e alcance os seus objetivos.</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-600 rounded-full text-sm font-bold">
          <BookOpen className="w-4 h-4" />
          {purchasedCourses.length} Cursos Ativos
        </div>
      </div>

      {purchasedCourses.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {purchasedCourses.map(course => (
            <div 
              key={course.id} 
              className="bg-white rounded-[32px] border border-slate-200 overflow-hidden hover:shadow-xl hover:shadow-slate-100 transition-all group flex flex-col"
            >
              <div className="relative aspect-video overflow-hidden">
                <img 
                  src={course.thumbnail} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                  referrerPolicy="no-referrer" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <button 
                    onClick={() => toast.info(`A carregar conteúdo de: ${course.title}`)}
                    className="px-6 py-3 bg-white text-slate-900 font-bold rounded-2xl shadow-lg transform translate-y-4 group-hover:translate-y-0 transition-all duration-300"
                  >
                    Continuar a Estudar
                  </button>
                </div>
              </div>
              
              <div className="p-6 flex-1 flex flex-col space-y-4">
                <div>
                  <h3 className="font-bold text-slate-900 leading-tight mb-1 group-hover:text-orange-600 transition-colors line-clamp-2">
                    {course.title}
                  </h3>
                  <p className="text-xs text-slate-500">{course.instructor}</p>
                </div>

                <div className="mt-auto space-y-2">
                  <div className="flex justify-between items-end">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Progresso</span>
                    <span className="text-sm font-black text-slate-900">{course.progress}%</span>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${course.progress}%` }}
                      transition={{ duration: 1, ease: "easeOut" }}
                      className="h-full bg-orange-600 rounded-full"
                    />
                  </div>
                </div>

                <button 
                  onClick={() => toast.info(`A carregar conteúdo de: ${course.title}`)}
                  className="w-full py-3 bg-slate-50 text-slate-900 font-bold rounded-xl hover:bg-orange-600 hover:text-white transition-all text-sm"
                >
                  Abrir Curso
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-slate-50 rounded-[40px] border-2 border-dashed border-slate-200">
          <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm">
            <BookOpen className="w-10 h-10 text-slate-300" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">Ainda não tens cursos</h3>
          <p className="text-slate-500 mb-8 max-w-xs mx-auto">Explora o nosso catálogo e começa a aprender hoje mesmo.</p>
          <Link 
            to="/" 
            className="px-8 py-4 bg-orange-600 text-white font-bold rounded-2xl hover:bg-orange-700 transition-all shadow-lg shadow-orange-100"
          >
            Explorar Cursos
          </Link>
        </div>
      )}
    </div>
  );
};

const LessonVideoPlayer = ({ 
  videoUrl, 
  onUpload 
}: { 
  videoUrl: string; 
  onUpload: (file: File) => void 
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsUploading(true);
      setProgress(0);
      
      // Simular progresso de upload
      let currentProgress = 0;
      const interval = setInterval(() => {
        currentProgress += Math.floor(Math.random() * 15) + 5;
        if (currentProgress >= 100) {
          currentProgress = 100;
          clearInterval(interval);
          setTimeout(() => {
            setIsUploading(false);
            onUpload(file);
            toast.success("Vídeo carregado com sucesso!");
          }, 500);
        }
        setProgress(currentProgress);
      }, 400);
    }
  };

  if (isUploading) {
    return (
      <div className="mt-2 space-y-2 w-full max-w-sm bg-slate-50 p-3 rounded-xl border border-slate-100">
        <div className="flex justify-between items-center text-[10px] font-bold text-slate-500 uppercase tracking-wider">
          <span className="flex items-center gap-1.5">
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-2.5 h-2.5 border-2 border-orange-600 border-t-transparent rounded-full"
            />
            A carregar vídeo...
          </span>
          <span>{progress}%</span>
        </div>
        <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            className="h-full bg-orange-600"
          />
        </div>
      </div>
    );
  }

  if (videoUrl) {
    return (
      <div className="space-y-2 mt-2">
        <video 
          src={videoUrl} 
          controls 
          className="w-full max-w-sm aspect-video rounded-xl bg-slate-900 shadow-lg"
        />
        <button 
          onClick={() => fileInputRef.current?.click()}
          className="text-[10px] font-bold text-orange-600 hover:underline flex items-center gap-1"
        >
          <Upload className="w-3 h-3" />
          Alterar Vídeo
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            accept="video/*" 
            className="hidden" 
          />
        </button>
      </div>
    );
  }

  return (
    <div className="mt-1">
      <button 
        onClick={() => fileInputRef.current?.click()}
        className="text-[10px] font-bold text-orange-600 hover:underline flex items-center gap-1"
      >
        <FileVideo className="w-3 h-3" />
        Upload de Vídeo
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileChange} 
          accept="video/*" 
          className="hidden" 
        />
      </button>
    </div>
  );
};

const CreateCoursePage = () => {
  const navigate = useNavigate();
  const thumbnailInputRef = useRef<HTMLInputElement>(null);
  const [courseData, setCourseData] = useState({
    title: "",
    category: "Tecnologia",
    price: "",
    description: "",
    thumbnailUrl: "",
  });

  const [modules, setModules] = useState<Module[]>([
    { id: "m1", title: "Módulo 1: Introdução", lessons: [{ id: "l1", title: "Aula 1: Bem-vindo", videoUrl: "", duration: "5:00" }] }
  ]);

  const addModule = () => {
    const newModule: Module = {
      id: `m${Date.now()}`,
      title: `Novo Módulo ${modules.length + 1}`,
      lessons: []
    };
    setModules([...modules, newModule]);
    toast.success("Módulo adicionado!");
  };

  const removeModule = (moduleId: string) => {
    setModules(modules.filter(m => m.id !== moduleId));
    toast.error("Módulo removido");
  };

  const addLesson = (moduleId: string) => {
    setModules(modules.map(m => {
      if (m.id === moduleId) {
        return {
          ...m,
          lessons: [...m.lessons, { id: `l${Date.now()}`, title: `Nova Aula ${m.lessons.length + 1}`, videoUrl: "", duration: "10:00" }]
        };
      }
      return m;
    }));
    toast.success("Aula adicionada!");
  };

  const removeLesson = (moduleId: string, lessonId: string) => {
    setModules(modules.map(m => {
      if (m.id === moduleId) {
        return { ...m, lessons: m.lessons.filter(l => l.id !== lessonId) };
      }
      return m;
    }));
    toast.error("Aula removida");
  };

  const handleVideoUpload = (moduleId: string, lessonId: string, file: File) => {
    const url = URL.createObjectURL(file);
    setModules(modules.map(m => {
      if (m.id === moduleId) {
        return {
          ...m,
          lessons: m.lessons.map(l => {
            if (l.id === lessonId) {
              return { ...l, videoUrl: url };
            }
            return l;
          })
        };
      }
      return m;
    }));
    toast.success("Vídeo carregado!");
  };

  const handleImageUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setCourseData({ ...courseData, thumbnailUrl: url });
      toast.success("Miniatura carregada!");
    }
  };

  const handleSave = () => {
    if (!courseData.title) {
      toast.error("Por favor, insira um título para o curso.");
      return;
    }
    toast.success("Curso guardado com sucesso! (Simulação)");
    navigate("/instrutor");
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-12 space-y-12">
      <div className="flex items-center justify-between">
        <button onClick={() => navigate("/instrutor")} className="flex items-center gap-2 text-slate-500 hover:text-slate-900 font-bold transition-colors">
          <ArrowLeft className="w-5 h-5" />
          Voltar ao Painel
        </button>
        <button onClick={handleSave} className="px-8 py-3 bg-orange-600 text-white font-bold rounded-xl hover:bg-orange-700 transition-all shadow-lg shadow-orange-100">
          Publicar Curso
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Course Info */}
        <div className="lg:col-span-1 space-y-8">
          <div className="bg-white p-8 rounded-3xl border border-slate-200 space-y-6">
            <h2 className="text-xl font-bold text-slate-900">Informações Básicas</h2>
            
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-400 uppercase">Título do Curso</label>
                <input 
                  type="text" 
                  value={courseData.title}
                  onChange={(e) => setCourseData({...courseData, title: e.target.value})}
                  placeholder="Ex: Marketing Digital em Luanda"
                  className="w-full mt-1 p-3 bg-slate-50 border border-slate-100 rounded-xl focus:ring-2 focus:ring-orange-500/20 outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-400 uppercase">Categoria</label>
                <select 
                  value={courseData.category}
                  onChange={(e) => setCourseData({...courseData, category: e.target.value})}
                  className="w-full mt-1 p-3 bg-slate-50 border border-slate-100 rounded-xl focus:ring-2 focus:ring-orange-500/20 outline-none"
                >
                  <option>Tecnologia</option>
                  <option>Negócios</option>
                  <option>Finanças</option>
                  <option>Estilo de Vida</option>
                  <option>Línguas</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-400 uppercase">Preço (Kz)</label>
                <input 
                  type="number" 
                  value={courseData.price}
                  onChange={(e) => setCourseData({...courseData, price: e.target.value})}
                  placeholder="Ex: 15000"
                  className="w-full mt-1 p-3 bg-slate-50 border border-slate-100 rounded-xl focus:ring-2 focus:ring-orange-500/20 outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-400 uppercase">Descrição</label>
                <textarea 
                  rows={4}
                  value={courseData.description}
                  onChange={(e) => setCourseData({...courseData, description: e.target.value})}
                  placeholder="Descreva o que os alunos vão aprender..."
                  className="w-full mt-1 p-3 bg-slate-50 border border-slate-100 rounded-xl focus:ring-2 focus:ring-orange-500/20 outline-none resize-none"
                />
              </div>
            </div>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-200 space-y-4">
            <h2 className="text-xl font-bold text-slate-900">Miniatura</h2>
            <div 
              onClick={() => thumbnailInputRef.current?.click()}
              className="aspect-video bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center gap-2 text-slate-400 hover:border-orange-200 hover:bg-orange-50/30 transition-all cursor-pointer group relative overflow-hidden"
            >
              {courseData.thumbnailUrl ? (
                <img 
                  src={courseData.thumbnailUrl} 
                  alt="Thumbnail Preview" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <>
                  <Upload className="w-8 h-8 group-hover:text-orange-600" />
                  <span className="text-xs font-bold">Upload de Imagem</span>
                </>
              )}
              <input 
                type="file" 
                ref={thumbnailInputRef} 
                onChange={handleImageUpload} 
                accept="image/*" 
                className="hidden" 
              />
            </div>
          </div>
        </div>

        {/* Curriculum Builder */}
        <div className="lg:col-span-2 space-y-8">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-black text-slate-900">Currículo do Curso</h2>
            <button 
              onClick={addModule}
              className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-900 font-bold rounded-xl hover:bg-slate-200 transition-all"
            >
              <PlusCircle className="w-4 h-4" />
              Adicionar Módulo
            </button>
          </div>

          <div className="space-y-6">
            {modules.map((module, mIdx) => (
              <div key={module.id} className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                <div className="p-6 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    <GripVertical className="w-5 h-5 text-slate-300 cursor-grab" />
                    <input 
                      type="text" 
                      value={module.title}
                      onChange={(e) => {
                        const newModules = [...modules];
                        newModules[mIdx].title = e.target.value;
                        setModules(newModules);
                      }}
                      className="bg-transparent font-bold text-slate-900 outline-none focus:ring-2 focus:ring-orange-500/20 rounded px-2 py-1 flex-1"
                    />
                  </div>
                  <button onClick={() => removeModule(module.id)} className="p-2 text-slate-400 hover:text-red-500 transition-colors">
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>

                <div className="p-6 space-y-4">
                  {module.lessons.map((lesson, lIdx) => (
                    <div key={lesson.id} className="flex items-center gap-4 p-4 bg-white border border-slate-100 rounded-2xl group hover:border-orange-200 transition-all">
                      <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 group-hover:bg-orange-50 group-hover:text-orange-600">
                        <Video className="w-5 h-5" />
                      </div>
                      <div className="flex-1">
                        <input 
                          type="text" 
                          value={lesson.title}
                          onChange={(e) => {
                            const newModules = [...modules];
                            newModules[mIdx].lessons[lIdx].title = e.target.value;
                            setModules(newModules);
                          }}
                          className="w-full text-sm font-bold text-slate-700 outline-none bg-transparent"
                        />
                        <div className="flex flex-col items-start gap-2">
                          <LessonVideoPlayer 
                            videoUrl={lesson.videoUrl} 
                            onUpload={(file) => handleVideoUpload(module.id, lesson.id, file)} 
                          />
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] text-slate-300">•</span>
                            <span className="text-[10px] text-slate-400">{lesson.duration}</span>
                          </div>
                        </div>
                      </div>
                      <button onClick={() => removeLesson(module.id, lesson.id)} className="p-2 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}

                  <button 
                    onClick={() => addLesson(module.id)}
                    className="w-full py-4 border-2 border-dashed border-slate-100 rounded-2xl text-slate-400 hover:border-orange-200 hover:bg-orange-50/30 hover:text-orange-600 transition-all font-bold text-sm flex items-center justify-center gap-2"
                  >
                    <PlusCircle className="w-4 h-4" />
                    Adicionar Aula
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const HowItWorksModal = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => {
  const steps = [
    {
      role: "Aluno",
      color: "orange",
      icon: <GraduationCap className="w-6 h-6 text-orange-600" />,
      items: [
        { title: "Escolha o seu curso", desc: "Navegue pelo catálogo e encontre o curso ideal para si.", icon: <Search className="w-4 h-4" /> },
        { title: "Pagamento Local", desc: "Pague via Multicaixa Express ou Transferência (IBAN).", icon: <CreditCard className="w-4 h-4" /> },
        { title: "Aprenda ao seu ritmo", desc: "Aceda às aulas e materiais de apoio vitalícios.", icon: <Zap className="w-4 h-4" /> },
      ]
    },
    {
      role: "Instrutor",
      color: "blue",
      icon: <Video className="w-6 h-6 text-blue-600" />,
      items: [
        { title: "Crie o seu conteúdo", desc: "Faça upload de vídeos e organize o seu currículo.", icon: <PlusCircle className="w-4 h-4" /> },
        { title: "Defina o seu preço", desc: "Você decide quanto vale o seu conhecimento.", icon: <DollarSign className="w-4 h-4" /> },
        { title: "Receba os seus ganhos", desc: "Saque os seus lucros diretamente para a sua conta.", icon: <Building2 className="w-4 h-4" /> },
      ]
    },
    {
      role: "Afiliado",
      color: "green",
      icon: <TrendingUp className="w-6 h-6 text-green-600" />,
      items: [
        { title: "Gere o seu link", desc: "Obtenha links exclusivos para promover cursos.", icon: <LinkIcon className="w-4 h-4" /> },
        { title: "Partilhe e venda", desc: "Divulgue nas suas redes sociais e ganhe comissões.", icon: <Users className="w-4 h-4" /> },
        { title: "Cresça connosco", desc: "Acompanhe as suas vendas e suba de nível.", icon: <Rocket className="w-4 h-4" /> },
      ]
    }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-4xl bg-white rounded-[40px] overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
          >
            <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h2 className="text-2xl font-black text-slate-900">Como Funciona a AngoLearn?</h2>
                <p className="text-slate-500 text-sm">Tudo o que precisa de saber para começar hoje.</p>
              </div>
              <button onClick={onClose} className="p-2 hover:bg-white rounded-full transition-colors shadow-sm">
                <X className="w-6 h-6 text-slate-400" />
              </button>
            </div>

            <div className="p-8 overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {steps.map((section, idx) => ( section && (
                  <div key={idx} className="space-y-6">
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm",
                        section.color === "orange" ? "bg-orange-50" : section.color === "blue" ? "bg-blue-50" : "bg-green-50"
                      )}>
                        {section.icon}
                      </div>
                      <h3 className="text-lg font-black text-slate-900 uppercase tracking-wider">{section.role}</h3>
                    </div>

                    <div className="space-y-4">
                      {section.items.map((item, iIdx) => (
                        <div key={iIdx} className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-2 group hover:bg-white hover:border-orange-200 transition-all">
                          <div className="flex items-center gap-2">
                            <div className="p-1.5 bg-white rounded-lg shadow-sm text-slate-400 group-hover:text-orange-600 transition-colors">
                              {item.icon}
                            </div>
                            <h4 className="font-bold text-slate-900 text-sm">{item.title}</h4>
                          </div>
                          <p className="text-xs text-slate-500 leading-relaxed">{item.desc}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )))}
              </div>

              <div className="mt-12 p-6 bg-orange-600 rounded-[32px] text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl shadow-orange-100">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold">Segurança Garantida</h4>
                    <p className="text-orange-100 text-xs">Pagamentos seguros e suporte local 24/7.</p>
                  </div>
                </div>
                <button 
                  onClick={onClose}
                  className="px-8 py-3 bg-white text-orange-600 font-bold rounded-xl hover:bg-orange-50 transition-all active:scale-95 whitespace-nowrap"
                >
                  Começar Agora
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const TipsModal = ({ isOpen, onClose, type }: { isOpen: boolean; onClose: () => void; type: 'mobile' | 'promo' }) => {
  const content = {
    mobile: {
      title: "Otimização para Mobile",
      description: "Em Angola, a maioria dos alunos acede via dados móveis. Siga estas dicas para aumentar a retenção:",
      tips: [
        { title: "Vídeos Curtos", desc: "Mantenha as aulas entre 5 a 10 minutos para facilitar o download.", icon: <Video className="w-5 h-5 text-blue-600" /> },
        { title: "Resolução Adaptativa", desc: "Ofereça opções de 360p e 480p para poupar saldo de dados.", icon: <Smartphone className="w-5 h-5 text-orange-600" /> },
        { title: "Materiais Offline", desc: "Disponibilize PDFs leves para leitura sem internet.", icon: <FileVideo className="w-5 h-5 text-green-600" /> }
      ]
    },
    promo: {
      title: "Configurar Promoção",
      description: "Aumente as suas vendas com campanhas estratégicas para o mercado local:",
      tips: [
        { title: "Promoção de Fim de Mês", desc: "Crie descontos entre os dias 25 e 5, quando há mais liquidez.", icon: <DollarSign className="w-5 h-5 text-green-600" /> },
        { title: "Cupões WhatsApp", desc: "Gere códigos curtos para partilhar facilmente em grupos.", icon: <Users className="w-5 h-5 text-blue-600" /> },
        { title: "Pacotes de Cursos", desc: "Ofereça 2 cursos pelo preço de 1.5 para aumentar o ticket médio.", icon: <PlusCircle className="w-5 h-5 text-orange-600" /> }
      ]
    }
  };

  const active = content[type];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-md bg-white rounded-[32px] overflow-hidden shadow-2xl"
          >
            <div className="p-8 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-bold text-slate-900">{active.title}</h3>
                <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>
              
              <p className="text-slate-500 text-sm leading-relaxed">{active.description}</p>
              
              <div className="space-y-4">
                {active.tips.map((tip, i) => (
                  <div key={i} className="flex gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm shrink-0">
                      {tip.icon}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{tip.title}</h4>
                      <p className="text-xs text-slate-500 leading-relaxed">{tip.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              <button 
                onClick={onClose}
                className="w-full py-4 bg-slate-900 text-white font-bold rounded-2xl hover:bg-slate-800 transition-all"
              >
                Entendido
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const WithdrawalModal = ({ 
  isOpen, 
  onClose, 
  balance 
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  balance: number;
}) => {
  const [step, setStep] = useState(1);
  const [method, setMethod] = useState<"express" | "iban" | null>(null);
  const [amount, setAmount] = useState("");

  const handleWithdraw = () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast.error("Por favor, insira um valor válido.");
      return;
    }
    if (parseFloat(amount) > balance) {
      toast.error("Saldo insuficiente.");
      return;
    }
    setStep(4);
    toast.success("Pedido de levantamento enviado!");
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-lg bg-white rounded-[32px] overflow-hidden shadow-2xl"
          >
            <div className="p-8">
              {step === 1 ? (
                <div className="space-y-6">
                  <div className="text-center">
                    <h3 className="text-2xl font-bold text-slate-900">Quanto deseja sacar?</h3>
                    <p className="text-slate-500">Saldo disponível: <span className="font-bold text-slate-900">{balance.toLocaleString('pt-AO')} Kz</span></p>
                  </div>
                  <div className="relative">
                    <input 
                      type="number" 
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0"
                      className="w-full p-6 text-4xl font-black text-center bg-slate-50 border-2 border-slate-100 rounded-3xl outline-none focus:border-orange-600 transition-all"
                    />
                    <span className="absolute right-6 top-1/2 -translate-y-1/2 font-bold text-slate-400">Kz</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {[0.25, 0.5, 0.75, 1].map(percent => (
                      <button 
                        key={percent}
                        onClick={() => setAmount((balance * percent).toString())}
                        className="py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-bold text-slate-600 transition-all"
                      >
                        {percent * 100}%
                      </button>
                    ))}
                  </div>
                  <button 
                    onClick={() => setStep(2)}
                    disabled={!amount || parseFloat(amount) <= 0}
                    className="w-full py-4 bg-orange-600 text-white font-bold rounded-2xl hover:bg-orange-700 transition-all disabled:opacity-50"
                  >
                    Continuar
                  </button>
                </div>
              ) : step === 2 ? (
                <div className="space-y-6">
                  <div className="text-center">
                    <h3 className="text-2xl font-bold text-slate-900">Método de Recebimento</h3>
                    <p className="text-slate-500">Escolha como deseja receber o seu dinheiro.</p>
                  </div>
                  <div className="grid grid-cols-1 gap-3">
                    <button 
                      onClick={() => { setMethod("express"); setStep(3); }}
                      className="p-4 border-2 border-slate-100 rounded-2xl hover:border-orange-600 hover:bg-orange-50 transition-all text-left flex items-center justify-between group"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600">
                          <Smartphone className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="font-bold text-slate-900">Multicaixa Express</p>
                          <p className="text-xs text-slate-500">Levantamento via número de telemóvel</p>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-orange-600" />
                    </button>
                    <button 
                      onClick={() => { setMethod("iban"); setStep(3); }}
                      className="p-4 border-2 border-slate-100 rounded-2xl hover:border-orange-600 hover:bg-orange-50 transition-all text-left flex items-center justify-between group"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center text-green-600">
                          <Building2 className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="font-bold text-slate-900">Transferência Bancária</p>
                          <p className="text-xs text-slate-500">Depósito direto na sua conta (IBAN)</p>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-orange-600" />
                    </button>
                  </div>
                  <button onClick={() => setStep(1)} className="w-full py-2 text-slate-400 font-bold text-sm hover:text-slate-600">
                    Voltar
                  </button>
                </div>
              ) : step === 3 ? (
                <div className="space-y-6">
                  <div className="text-center">
                    <h3 className="text-2xl font-bold text-slate-900">Dados do Recebimento</h3>
                    <p className="text-slate-500">Preencha os dados para processarmos o saque.</p>
                  </div>
                  
                  {method === "express" ? (
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-sm font-bold text-slate-700">Número de Telemóvel (Express)</label>
                        <input 
                          type="tel" 
                          placeholder="9XX XXX XXX"
                          className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-orange-600"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-sm font-bold text-slate-700">Banco</label>
                        <select className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-orange-600">
                          <option>BAI</option>
                          <option>BFA</option>
                          <option>BIC</option>
                          <option>Standard Bank</option>
                          <option>BPC</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-bold text-slate-700">IBAN</label>
                        <input 
                          type="text" 
                          placeholder="AO06 ...."
                          className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-orange-600 font-mono"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-bold text-slate-700">Titular da Conta</label>
                        <input 
                          type="text" 
                          placeholder="Nome completo"
                          className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-orange-600"
                        />
                      </div>
                    </div>
                  )}

                  <div className="pt-4 space-y-3">
                    <button 
                      onClick={handleWithdraw}
                      className="w-full py-4 bg-orange-600 text-white font-bold rounded-2xl hover:bg-orange-700 transition-all"
                    >
                      Confirmar Saque
                    </button>
                    <button onClick={() => setStep(2)} className="w-full py-2 text-slate-400 font-bold text-sm hover:text-slate-600">
                      Voltar
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-6 text-center py-4">
                  <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="text-green-600 w-10 h-10" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-slate-900">Pedido Enviado!</h3>
                    <p className="text-slate-500 px-4">O seu saque de <span className="font-bold text-slate-900">{parseFloat(amount).toLocaleString('pt-AO')} Kz</span> está a ser processado e será creditado em até 48h.</p>
                  </div>
                  <button 
                    onClick={onClose}
                    className="w-full py-4 bg-slate-900 text-white font-bold rounded-2xl"
                  >
                    Concluído
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const InstructorDashboard = () => {
  const stats = MOCK_STATS.instructor;
  const navigate = useNavigate();
  const [isWithdrawalModalOpen, setIsWithdrawalModalOpen] = useState(false);
  const [isTipsModalOpen, setIsTipsModalOpen] = useState(false);
  const [tipsType, setTipsType] = useState<'mobile' | 'promo'>('mobile');

  const handleCreateCourse = () => {
    navigate("/instrutor/novo-curso");
  };

  const handleViewAllSales = () => {
    toast.info("Carregando histórico completo de vendas...");
  };

  const handleOptimizeMobile = () => {
    setTipsType('mobile');
    setIsTipsModalOpen(true);
  };

  const handleSetupPromo = () => {
    setTipsType('promo');
    setIsTipsModalOpen(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10">
      <TipsModal 
        isOpen={isTipsModalOpen} 
        onClose={() => setIsTipsModalOpen(false)} 
        type={tipsType} 
      />
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-900">Painel do Instrutor</h1>
          <p className="text-slate-500">Gerencie seus cursos e acompanhe seus ganhos.</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <button 
            onClick={() => setIsWithdrawalModalOpen(true)}
            className="flex items-center gap-2 px-6 py-3 bg-white text-slate-900 font-bold rounded-xl border border-slate-200 hover:bg-slate-50 transition-all shadow-sm"
          >
            <DollarSign className="w-5 h-5 text-green-600" />
            Sacar Saldo
          </button>
          <button 
            onClick={handleCreateCourse}
            className="flex items-center gap-2 px-6 py-3 bg-orange-600 text-white font-bold rounded-xl hover:bg-orange-700 transition-all shadow-lg shadow-orange-100"
          >
            <PlusCircle className="w-5 h-5" />
            Criar Novo Curso
          </button>
        </div>
      </div>

      <WithdrawalModal 
        isOpen={isWithdrawalModalOpen} 
        onClose={() => setIsWithdrawalModalOpen(false)} 
        balance={stats.totalEarnings} 
      />

      {/* Commission Split Info */}
      <div className="bg-orange-50 border border-orange-100 rounded-3xl p-6 flex flex-col md:flex-row items-center gap-6">
        <div className="w-12 h-12 bg-orange-600 rounded-2xl flex items-center justify-center shrink-0">
          <DollarSign className="text-white w-6 h-6" />
        </div>
        <div className="flex-1 text-center md:text-left">
          <h3 className="font-bold text-slate-900">Divisão Automática de Comissões</h3>
          <p className="text-sm text-slate-600">
            O AngoLearn automatiza os seus ganhos: <span className="font-bold text-orange-600">70% para si</span>, 20% para afiliados que promovem o seu curso e 10% de taxa de manutenção do sistema.
          </p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: "Ganhos Líquidos (70%)", value: `${stats.totalEarnings.toLocaleString('pt-AO')} Kz`, icon: DollarSign, color: "bg-green-50 text-green-600" },
          { label: "Alunos Totais", value: stats.totalStudents, icon: Users, color: "bg-blue-50 text-blue-600" },
          { label: "Cursos Ativos", value: stats.activeCourses, icon: BookOpen, color: "bg-orange-50 text-orange-600" },
          { label: "Taxa do Sistema (10%)", value: `${(stats.totalEarnings / 0.7 * 0.1).toLocaleString('pt-AO')} Kz`, icon: TrendingUp, color: "bg-purple-50 text-purple-600" },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl border border-slate-200 space-y-4">
            <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center", stat.color)}>
              <stat.icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">{stat.label}</p>
              <p className="text-2xl font-black text-slate-900">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Sales */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-bold text-slate-900">Vendas Recentes</h3>
            <button 
              onClick={handleViewAllSales}
              className="text-xs font-bold text-orange-600 hover:underline"
            >
              Ver todas
            </button>
          </div>
          <div className="divide-y divide-slate-50">
            {stats.recentSales.map(sale => (
              <div key={sale.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center font-bold text-slate-500 text-xs">
                    {sale.student.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-900">{sale.student}</p>
                    <p className="text-[10px] text-slate-400">{sale.course} • {sale.date}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-black text-slate-900">+{calculateSplit(sale.amount).creator.toLocaleString('pt-AO')} Kz</p>
                  <p className="text-[10px] text-slate-400">Líquido (70%)</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-slate-900 rounded-3xl p-8 text-white space-y-6">
          <h3 className="text-xl font-bold">Dicas para Vender Mais</h3>
          <p className="text-slate-400 text-sm leading-relaxed">
            Sabia que cursos com vídeos curtos (5-10 min) têm 40% mais conclusão em Angola devido ao custo de dados móveis?
          </p>
          <div className="space-y-3">
            <button 
              onClick={handleOptimizeMobile}
              className="w-full p-4 bg-white/10 hover:bg-white/20 rounded-2xl text-left text-sm font-bold transition-all flex items-center justify-between group"
            >
              Otimizar para Mobile
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
            <button 
              onClick={handleSetupPromo}
              className="w-full p-4 bg-white/10 hover:bg-white/20 rounded-2xl text-left text-sm font-bold transition-all flex items-center justify-between group"
            >
              Configurar Promoção
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const AffiliateDashboard = () => {
  const stats = MOCK_STATS.affiliate;
  const [isWithdrawalModalOpen, setIsWithdrawalModalOpen] = useState(false);

  const handleCopyLink = (courseId: string) => {
    const link = `angolearn.ao/c/${courseId}?ref=user123`;
    navigator.clipboard.writeText(link);
    toast.success("Link de afiliado copiado!");
  };

  const handleDetailedReport = () => {
    toast.info("Gerando relatório detalhado de conversões...");
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-900">Painel de Afiliado</h1>
          <p className="text-slate-500">Promova cursos e ganhe comissões por cada venda.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsWithdrawalModalOpen(true)}
            className="flex items-center gap-2 px-6 py-3 bg-white text-slate-900 font-bold rounded-xl border border-slate-200 hover:bg-slate-50 transition-all shadow-sm"
          >
            <DollarSign className="w-5 h-5 text-green-600" />
            Sacar Saldo
          </button>
          <div className="flex items-center gap-2 px-4 py-2 bg-orange-100 text-orange-700 rounded-full">
            <Award className="w-5 h-5" />
            <span className="text-sm font-bold">Nível {stats.rank}</span>
          </div>
        </div>
      </div>

      <WithdrawalModal 
        isOpen={isWithdrawalModalOpen} 
        onClose={() => setIsWithdrawalModalOpen(false)} 
        balance={stats.totalCommission} 
      />

      {/* Commission Info Box */}
      <div className="bg-blue-50 border border-blue-100 rounded-3xl p-6 flex flex-col md:flex-row items-center gap-6">
        <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center shrink-0">
          <LinkIcon className="text-white w-6 h-6" />
        </div>
        <div className="flex-1 text-center md:text-left">
          <h3 className="font-bold text-slate-900">Como funcionam as suas comissões</h3>
          <p className="text-sm text-slate-600">
            Recebe automaticamente <span className="font-bold text-blue-600">20% de comissão</span> sobre o valor de cada curso vendido através do seu link. O pagamento é processado instantaneamente após a confirmação da venda.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: "Comissões (20%)", value: `${stats.totalCommission.toLocaleString('pt-AO')} Kz`, icon: DollarSign, color: "bg-green-50 text-green-600" },
          { label: "Cliques", value: stats.totalClicks, icon: LinkIcon, color: "bg-blue-50 text-blue-600" },
          { label: "Conversões", value: stats.conversions, icon: CheckCircle2, color: "bg-orange-50 text-orange-600" },
          { label: "Saldo Disponível", value: "125.000 Kz", icon: CreditCard, color: "bg-purple-50 text-purple-600" },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl border border-slate-200 space-y-4">
            <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center", stat.color)}>
              <stat.icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">{stat.label}</p>
              <p className="text-2xl font-black text-slate-900">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden">
            <div className="p-6 border-b border-slate-100">
              <h3 className="font-bold text-slate-900">Cursos com Melhor Comissão</h3>
            </div>
            <div className="divide-y divide-slate-50">
              {COURSES.slice(0, 3).map(course => (
                <div key={course.id} className="p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <img src={course.thumbnail} className="w-16 h-12 rounded-lg object-cover" referrerPolicy="no-referrer" />
                    <div>
                      <p className="text-sm font-bold text-slate-900">{course.title}</p>
                      <p className="text-xs text-slate-500">Comissão: <span className="text-green-600 font-bold">20%</span></p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <input 
                      readOnly 
                      value={`angolearn.ao/c/${course.id}?ref=user123`} 
                      className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 w-48 font-mono outline-none"
                    />
                    <button 
                      onClick={() => handleCopyLink(course.id)}
                      className="p-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-orange-600 rounded-3xl p-8 text-white">
            <BarChart3 className="w-10 h-10 mb-4 opacity-50" />
            <h3 className="text-xl font-bold mb-2">Desempenho Semanal</h3>
            <p className="text-orange-100 text-sm mb-6">Os teus cliques aumentaram 15% esta semana. Continua a partilhar no WhatsApp!</p>
            <button 
              onClick={handleDetailedReport}
              className="w-full py-3 bg-white text-orange-600 font-bold rounded-xl hover:bg-orange-50 transition-all"
            >
              Ver Relatório Detalhado
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const LoginPage = ({ setIsAuthenticated, role, isAuthenticated }: { setIsAuthenticated: (a: boolean) => void, role: UserRole, isAuthenticated: boolean }) => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    if (isAuthenticated) {
      if (role === "student") navigate("/meus-cursos");
      else if (role === "instructor") navigate("/instrutor");
      else if (role === "affiliate") navigate("/afiliado");
    }
  }, [isAuthenticated, role, navigate]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) {
      setIsAuthenticated(true);
      toast.success("Bem-vindo de volta!");
      if (role === "student") navigate("/meus-cursos");
      else if (role === "instructor") navigate("/instrutor");
      else if (role === "affiliate") navigate("/afiliado");
    } else {
      toast.error("Por favor, preencha todos os campos.");
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white rounded-[40px] border border-slate-100 shadow-2xl shadow-slate-200/50 p-10 space-y-8"
      >
        <div className="text-center space-y-2">
          <div className="w-16 h-16 bg-orange-600 rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-orange-100 mb-4">
            <GraduationCap className="text-white w-8 h-8" />
          </div>
          <h1 className="text-3xl font-black text-slate-900">Entrar</h1>
          <p className="text-slate-500 text-sm">Continue a sua jornada de aprendizagem.</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Email</label>
            <input 
              type="email" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com" 
              className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none transition-all text-sm"
            />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between ml-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Palavra-passe</label>
              <button type="button" className="text-[10px] font-bold text-orange-600 hover:underline">Esqueceu?</button>
            </div>
            <input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••" 
              className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none transition-all text-sm"
            />
          </div>

          <button 
            type="submit"
            className="w-full py-4 bg-slate-900 text-white font-bold rounded-2xl hover:bg-slate-800 transition-all shadow-xl shadow-slate-200 active:scale-[0.98]"
          >
            Entrar na Conta
          </button>
        </form>

        <div className="pt-6 border-t border-slate-50 text-center">
          <p className="text-sm text-slate-500">
            Não tem uma conta? <Link to="/cadastro" className="text-orange-600 font-bold hover:underline">Criar agora</Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
};

const RegisterPage = ({ setIsAuthenticated, role, isAuthenticated }: { setIsAuthenticated: (a: boolean) => void, role: UserRole, isAuthenticated: boolean }) => {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    if (isAuthenticated) {
      if (role === "student") navigate("/meus-cursos");
      else if (role === "instructor") navigate("/instrutor");
      else if (role === "affiliate") navigate("/afiliado");
    }
  }, [isAuthenticated, role, navigate]);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && email && password) {
      setIsAuthenticated(true);
      toast.success("Conta criada com sucesso!");
      if (role === "student") navigate("/meus-cursos");
      else if (role === "instructor") navigate("/instrutor");
      else if (role === "affiliate") navigate("/afiliado");
    } else {
      toast.error("Por favor, preencha todos os campos.");
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white rounded-[40px] border border-slate-100 shadow-2xl shadow-slate-200/50 p-10 space-y-8"
      >
        <div className="text-center space-y-2">
          <div className="w-16 h-16 bg-orange-600 rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-orange-100 mb-4">
            <GraduationCap className="text-white w-8 h-8" />
          </div>
          <h1 className="text-3xl font-black text-slate-900">Criar Conta</h1>
          <p className="text-slate-500 text-sm">Junte-se à maior comunidade de alunos em Angola.</p>
        </div>

        <form onSubmit={handleRegister} className="space-y-5">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Nome Completo</label>
            <input 
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Manuel dos Santos" 
              className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none transition-all text-sm"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Email</label>
            <input 
              type="email" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com" 
              className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none transition-all text-sm"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Palavra-passe</label>
            <input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Mínimo 8 caracteres" 
              className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none transition-all text-sm"
            />
          </div>

          <div className="flex items-start gap-3 ml-1">
            <input type="checkbox" id="terms" className="mt-1 rounded border-slate-300 text-orange-600 focus:ring-orange-500" required />
            <label htmlFor="terms" className="text-[10px] text-slate-500 leading-tight">
              Concordo com os <button type="button" className="text-orange-600 font-bold hover:underline">Termos de Uso</button> e a <button type="button" className="text-orange-600 font-bold hover:underline">Política de Privacidade</button>.
            </label>
          </div>

          <button 
            type="submit"
            className="w-full py-4 bg-orange-600 text-white font-bold rounded-2xl hover:bg-orange-700 transition-all shadow-xl shadow-orange-100 active:scale-[0.98]"
          >
            Criar Minha Conta
          </button>
        </form>

        <div className="pt-6 border-t border-slate-50 text-center">
          <p className="text-sm text-slate-500">
            Já tem uma conta? <Link to="/login" className="text-orange-600 font-bold hover:underline">Entrar</Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default function App() {
  const [role, setRole] = useState<UserRole>("student");
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleProfileSettings = () => {
    toast.info("Abrindo definições de perfil...");
  };

  const handlePaymentHistory = () => {
    toast.info("Carregando histórico de pagamentos...");
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    toast.error("Sessão terminada com sucesso.");
  };

  return (
    <Router>
      <Toaster position="top-center" richColors />
      <div className="min-h-screen bg-white font-sans text-slate-900 selection:bg-orange-100 selection:text-orange-900">
        <Navbar role={role} setRole={setRole} isAuthenticated={isAuthenticated} setIsAuthenticated={setIsAuthenticated} />
        <main>
          <Routes>
            <Route path="/" element={isAuthenticated ? <HomePage /> : <LoginPage setIsAuthenticated={setIsAuthenticated} role={role} isAuthenticated={isAuthenticated} />} />
            <Route path="/catalogo" element={<HomePage />} />
            <Route path="/login" element={<LoginPage setIsAuthenticated={setIsAuthenticated} role={role} isAuthenticated={isAuthenticated} />} />
            <Route path="/cadastro" element={<RegisterPage setIsAuthenticated={setIsAuthenticated} role={role} isAuthenticated={isAuthenticated} />} />
            <Route path="/curso/:id" element={<CourseDetailPage />} />
            <Route path="/meus-cursos" element={<MyCoursesPage />} />
            <Route path="/instrutor" element={<InstructorDashboard />} />
            <Route path="/afiliado" element={<AffiliateDashboard />} />
            <Route path="/instrutor/novo-curso" element={<CreateCoursePage />} />
            <Route path="/perfil" element={
              <div className="max-w-xl mx-auto py-20 px-4 text-center space-y-8">
                <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto border-4 border-white shadow-xl">
                  <User className="w-12 h-12 text-slate-400" />
                </div>
                <div>
                  <h1 className="text-3xl font-black text-slate-900">Kitanda Shop</h1>
                  <p className="text-slate-500">Membro desde Março 2026 • Luanda, Angola</p>
                </div>
                <div className="grid grid-cols-1 gap-3">
                  <button 
                    onClick={handleProfileSettings}
                    className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-2xl hover:bg-slate-50 transition-all group"
                  >
                    <div className="flex items-center gap-3">
                      <Settings className="w-5 h-5 text-slate-400" />
                      <span className="font-bold text-slate-700">Definições da Conta</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-300 group-hover:translate-x-1 transition-transform" />
                  </button>
                  <button 
                    onClick={handlePaymentHistory}
                    className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-2xl hover:bg-slate-50 transition-all group"
                  >
                    <div className="flex items-center gap-3">
                      <CreditCard className="w-5 h-5 text-slate-400" />
                      <span className="font-bold text-slate-700">Histórico de Pagamentos</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-300 group-hover:translate-x-1 transition-transform" />
                  </button>
                  <button 
                    onClick={handleLogout}
                    className="flex items-center justify-between p-4 bg-red-50 border border-red-100 rounded-2xl hover:bg-red-100 transition-all group mt-4"
                  >
                    <div className="flex items-center gap-3">
                      <LogOut className="w-5 h-5 text-red-400" />
                      <span className="font-bold text-red-600">Terminar Sessão</span>
                    </div>
                  </button>
                </div>
              </div>
            } />
          </Routes>
        </main>
        
        <footer className="bg-slate-900 text-white py-12 mt-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-12">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <GraduationCap className="text-orange-500 w-6 h-6" />
                <span className="text-xl font-bold tracking-tight">AngoLearn</span>
              </div>
              <p className="text-slate-400 text-sm leading-relaxed">
                A maior plataforma de educação online focada no desenvolvimento de Angola.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Plataforma</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><button onClick={() => toast.info("Redirecionando para Catálogo...")} className="hover:text-orange-500 transition-colors">Cursos</button></li>
                <li><button onClick={() => toast.info("Conheça nossos instrutores em breve!")} className="hover:text-orange-500 transition-colors">Instructores</button></li>
                <li><button onClick={() => toast.info("Informações sobre certificados disponíveis em breve.")} className="hover:text-orange-500 transition-colors">Certificados</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Suporte</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><button onClick={() => toast.info("Centro de Ajuda em manutenção.")} className="hover:text-orange-500 transition-colors">Ajuda</button></li>
                <li><button onClick={() => toast.info("Dúvidas sobre pagamentos? Contacte o suporte.")} className="hover:text-orange-500 transition-colors">Pagamentos</button></li>
                <li><button onClick={() => toast.info("Linha de apoio: +244 9XX XXX XXX")} className="hover:text-orange-500 transition-colors">Contacto</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><button onClick={() => toast.info("Termos de Uso atualizados em Março 2026.")} className="hover:text-orange-500 transition-colors">Termos de Uso</button></li>
                <li><button onClick={() => toast.info("Sua privacidade é nossa prioridade.")} className="hover:text-orange-500 transition-colors">Privacidade</button></li>
              </ul>
            </div>
          </div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-8 border-t border-slate-800 text-center text-slate-500 text-xs">
            © 2026 AngoLearn Digital Lda. Todos os direitos reservados. Feito em Luanda 🇦🇴
          </div>
        </footer>
      </div>
    </Router>
  );
}
